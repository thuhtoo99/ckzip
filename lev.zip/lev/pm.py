import requests
def extractpm(cnn, month, year, cvv):
   # print(cnn, month, year, cvv)
    url = "https://api.stripe.com/v1/payment_methods"
    
    data = f'billing_details[email]=singyi99099%40gmail.com&billing_details[name]=Niko&billing_details[address][country]=MM&type=card&card[number]={cnn}&card[cvc]={cvv}&card[exp_year]={year}&card[exp_month]={month}&allow_redisplay=unspecified&payment_user_agent=stripe.js%2Fe1fb22ad35%3B+stripe-js-v3%2Fe1fb22ad35%3B+payment-element&referrer=https%3A%2F%2Flevchabad.org&time_on_page=49225&guid=NA&muid=NA&sid=NA&key=pk_live_51KT2RvLSYBr599jmUYDUirjEvD3cu9kWKRQ6uJdleVILixsGu9vAl6gyT375v9hbm3GNAYU5rHg94eYLl4HEG77H004qAfe7Cc&_stripe_account=acct_1L2wEhA1epArP1Cp'
    
    headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
}
    
    response = requests.post(url, data=data, headers=headers)
    
    try:
        pm = response.json()['id']
        #}print(response.json())
        return pm
    except (KeyError, ValueError, Exception):
        return None
        
