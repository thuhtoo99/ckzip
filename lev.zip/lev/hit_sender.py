import requests

def send(cc, key, username, time_taken):
    ii = cc[:6]

    try:
        response = requests.get(f'https://data.handyapi.com/bin/'+ii)
        data = response.json()
        print(response.text)

        if "error" not in data:
            bank = data.get('Issuer', 'Unknow')
            emj = data.get('Country', {}).get('Cont', 'Unknow')
            do = data.get('Country', {}).get('Name','Unknow')
            dicr = data.get('CardTier', 'Unknown')
            typ = data.get('Type', 'Unknown')
        else:
            bank = emj = do = dicr = typ = 'Unknown'
    except Exception as e:
        print(f"Error fetching data from binchk API: {e}")
        bank = emj = do = dicr = typ = 'Unknown'

    msg1 = f"""
<b>GATEWAY ➜ Stripe 1$</b>
<b>RESPONSE ➜</b> {key}

<b>CC ➜</b> <code>{cc}</code>

<b>BIN ➜</b> {ii}
<b>COUNTRY ➜</b> {do}
<b>BANK ➜</b> {bank}
<b>FLAG ➜</b> {emj}
<b>BRAND ➜</b> {dicr}
<b>TYPE ➜</b> {typ}
<b>TIME ➜</b> {time_taken}s
"""

    return msg1
