import requests
def extractpm(cnn, month, year, cvv):
   # print(cnn, month, year, cvv)
    url = "https://api.stripe.com/v1/payment_methods"
    
    payload = f'type=card&card[number]={cnn}&card[cvc]={cvv}&card[exp_month]={month}&card[exp_year]={year}&billing_details[address][postal_code]=10004&payment_user_agent=stripe.js%2F332636417d%3B+stripe-js-v3%2F332636417d%3B+card-element&referrer=https%3A%2F%2Fwww.cobbmastergardeners.com&time_on_page=70805&client_attribution_metadata[client_session_id]=95edd21a-d7b1-4aab-b222-968cda83b6b7&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=card-element&client_attribution_metadata[merchant_integration_version]=2017&client_attribution_metadata[wallet_config_id]=5b0871dd-c437-48b8-8b45-e300fd1d3f96&key=pk_live_51S98p4JuXLdLHsyha3tmnfWRCaW5PXcbINdnkC2VmdrJgfR6RI5L1x69kBmQFF04ErQ3i4Egp2VCxDM6KOQErGh600VQmb6nfU'
    
    headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
}
    
    response = requests.post(url, data=payload, headers=headers)
    
    try:
        pm = response.json()['id']
        #}print(response.json())
        return pm
    except (KeyError, ValueError, Exception):
        return None
        
