import time
from telebot import TeleBot, types
from check import checker
from reg import reg
from hit_sender import send  

# Load the bot token
with open('token.txt', 'r') as token_file:
    token = token_file.read().strip()

bot = TeleBot(token, parse_mode="HTML") 

success_keys = [
    "Grazie per la vostra donazione ", "succeeded", "thanks for your support!",
    "thanks you for your donation", "Thank you", "success",
    "thank you. your order has been received."
]
insufficient_keys = ["insufficient funds.", "Fondo insufficiente"]
incorrect_keys = [
    "security code is incorrect.", "your card's security code is incorrect",
    "security code is invalid."
]
failure_keys = ["your card has been declined", "Your card was declined."]
threeds = ["Action"]

@bot.message_handler(commands=['c'])
def check_card(message):
    try:
        cc = message.text.split('/c', 1)[1].strip()
        user_id = message.from_user.id
        username = message.from_user.username or "NoUsername"

        msg = bot.reply_to(message, "Checking your card...")
        msg_id = msg.message_id  
        start_time = time.time()

        # Validate card format
        cc = reg(cc)
        if not cc:
            bot.edit_message_text(
                chat_id=message.chat.id, message_id=msg_id,
                text="Invalid card format. Please use the correct format: `cc|mm|yy|cvv`",
                parse_mode="Markdown"
            )
            return

        result2 = checker(cc)

        if any(k in result2 for k in success_keys):
            key = f"Charged"
        elif any(k in result2 for k in insufficient_keys):
            key = f"Insufficient Funds"
        elif any(k in result2 for k in incorrect_keys):
            key = f"Incorrect Security Code: {result2}"
        elif any(k in result2 for k in failure_keys):
            key = f"Your card was declined.: {result2}"
        elif any(k in result2 for k in threeds):
            key = f"Fuck Owner: {result2}"
        else:
            key = f"Unknown Response: {result2}"

        time_taken = round(time.time() - start_time, 2)

        send_response = send(cc, key, username, time_taken)

        print(send_response)

        
        try:
            bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=msg_id,
                text=send_response,
                parse_mode="HTML" 
            )
        except Exception as e:
            print(f"Error editing message: {e}")
            print(f"Problematic Response: {send_response}")
            bot.edit_message_text(
                chat_id=message.chat.id,
                message_id=msg_id,
                text="An error occurred while processing your request. Please try again later."
            )

    except Exception as e:
        bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=msg_id,
            text="An error occurred while processing your request."
        )
        print(f"Error: {e}")

# Start the bot
print("+-----------------------------------------------------------------+")
bot.infinity_polling(timeout=25, long_polling_timeout=5)
